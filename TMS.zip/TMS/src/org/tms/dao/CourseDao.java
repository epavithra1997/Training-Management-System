package org.tms.dao;

import org.tms.beans.course;

public interface CourseDao {
	public boolean insert(course r);
	
}
