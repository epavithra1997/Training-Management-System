package org.tms.services;

import org.tms.beans.course;

public interface courseservice {
	public boolean course(course r);

}
